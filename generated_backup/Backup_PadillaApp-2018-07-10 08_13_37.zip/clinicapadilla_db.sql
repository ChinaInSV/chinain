#
# TABLE STRUCTURE FOR: clientes
#

DROP TABLE IF EXISTS `clientes`;

CREATE TABLE `clientes` (
  `id_cliente` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_departamento` tinyint(2) unsigned DEFAULT NULL,
  `id_municipio` smallint(3) unsigned DEFAULT NULL,
  `fecha_registro_cliente` datetime DEFAULT NULL,
  `nombre_cliente` varchar(75) NOT NULL,
  `sexo_cliente` tinyint(1) NOT NULL,
  `razonsocial_cliente` varchar(75) NOT NULL,
  `clasificacion_cliente` tinyint(1) unsigned DEFAULT NULL,
  `dui_cliente` varchar(12) DEFAULT NULL,
  `nit_cliente` varchar(20) DEFAULT NULL,
  `ncr_cliente` varchar(10) DEFAULT NULL,
  `giro_cliente` varchar(255) DEFAULT NULL,
  `direccion_cliente` varchar(150) DEFAULT NULL,
  `nacionalidad_cliente` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `telefono1_cliente` varchar(24) DEFAULT NULL,
  `telefono2_cliente` varchar(24) DEFAULT NULL,
  `telefono3_cliente` varchar(24) DEFAULT NULL,
  `correo_cliente` varchar(75) DEFAULT NULL,
  `notas_cliente` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  KEY `departamento_cliente` (`id_departamento`,`id_municipio`),
  KEY `municipio_cliente` (`id_municipio`),
  CONSTRAINT `departamento_cliente_fk` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id_departamento`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `municipio_cliente_fk` FOREIGN KEY (`id_municipio`) REFERENCES `municipios` (`id_municipio`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (1, 13, 233, '2018-06-27 12:25:17', 'Donatila Argueta', 1, '', NULL, NULL, NULL, NULL, NULL, 'meanguera', 0, '78855776', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (2, 13, 243, '2018-06-27 14:23:31', 'Alejandra Marisol Flores', 1, '', NULL, NULL, NULL, NULL, NULL, 'yamabal', 0, '72939201', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (3, 13, 219, '2018-06-28 07:22:47', 'Yanci Elizabeth Luna Chicas', 1, '', NULL, NULL, NULL, NULL, NULL, 'colonia vista hermosa', 0, '74380877', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (9, 13, 228, '2018-06-28 08:59:14', 'Gilma Vigil Campos', 1, '', NULL, NULL, NULL, NULL, NULL, 'morazan', 0, '26586181', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (10, 13, 219, '2018-06-28 09:04:33', 'Juan Carlos Garcia ', 0, '', NULL, NULL, NULL, NULL, NULL, 'gotera', 0, '75409836', '26540215', NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (11, 13, 236, '2018-06-28 09:08:00', 'Kelly Vanessa Hernandez Perla', 1, '', NULL, NULL, NULL, NULL, NULL, 'san carlos', 0, '77643554', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (12, 13, 219, '2018-06-28 09:11:04', 'Evelyn Idalia Argueta Amaya', 1, '', NULL, NULL, NULL, NULL, NULL, 'gotera', 0, '0050497724004', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (14, 13, 219, '2018-06-28 09:35:25', 'Jose Antonio Hernandez', 0, '', NULL, NULL, NULL, NULL, NULL, 'gotera', 0, '70332517', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (15, 13, 223, '2018-06-28 09:41:32', 'Anderson Dodani Martinez', 0, '', NULL, NULL, NULL, NULL, NULL, 'chilanga', 0, '74558643', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (16, 13, 219, '2018-06-28 09:43:44', 'Edgar Alexander Ventura', 0, '', NULL, NULL, NULL, NULL, NULL, 'vista hermosa', 0, '26540951', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (17, 13, 240, '2018-06-28 09:49:19', 'Jeylin Andrea Amaya Hernandez', 1, '', NULL, NULL, NULL, NULL, NULL, 'sensembra', 0, '75558727', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (18, 13, 219, '2018-06-28 09:55:44', 'Erlinda Guadalupe Gonzales', 1, '', NULL, NULL, NULL, NULL, NULL, 'gotera', 0, '72906542', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (19, 13, 240, '2018-06-28 11:50:04', 'Sandra Vanessa Vasquez', 1, '', NULL, NULL, NULL, NULL, NULL, 'semsenbra', 0, '79395243', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (20, 14, 260, '2018-06-28 11:53:04', 'Kenia Ventura', 1, '', NULL, NULL, NULL, NULL, NULL, 'santa rosa', 0, '78574933', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (21, 13, 240, '2018-06-28 11:56:53', 'Inmer Misael Flores Benavidez', 0, '', NULL, NULL, NULL, NULL, NULL, 'sensembra', 0, '70208338', NULL, NULL, NULL, 'tiene que pagar 50$ de prima.');
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (22, 13, 244, '2018-06-28 11:59:04', 'Ruth Briseyda Fernandez', 1, '', NULL, NULL, NULL, NULL, NULL, 'yoloaiquin', 0, '26806866', NULL, NULL, NULL, 'Resta 150$ de prima.');
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (23, 13, 233, '2018-06-28 12:04:16', 'Diana Isabell Romero', 1, '', NULL, NULL, NULL, NULL, NULL, 'meanguera', 0, '76340200', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (24, 13, 224, '2018-06-28 12:06:42', 'Meyvin Julissa Hernandez', 1, '', NULL, NULL, NULL, NULL, NULL, 'delicias', 0, '79223315', NULL, NULL, NULL, NULL);
INSERT INTO `clientes` (`id_cliente`, `id_departamento`, `id_municipio`, `fecha_registro_cliente`, `nombre_cliente`, `sexo_cliente`, `razonsocial_cliente`, `clasificacion_cliente`, `dui_cliente`, `nit_cliente`, `ncr_cliente`, `giro_cliente`, `direccion_cliente`, `nacionalidad_cliente`, `telefono1_cliente`, `telefono2_cliente`, `telefono3_cliente`, `correo_cliente`, `notas_cliente`) VALUES (25, 13, 219, '2018-06-28 12:09:25', 'Elisa Madai Amaya', 1, '', NULL, NULL, NULL, NULL, NULL, 'gotera', 0, '79159770', NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `id_config` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `campo_config` varchar(64) NOT NULL,
  `valor_config` mediumtext,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (1, 'gral_info_nombre_empresa', 'Nombre de la Empresa|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (2, 'gral_info_propietario_empresa', 'Propietario de la Empresa|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (3, 'gral_info_direccion_empresa', 'Direccion de la Empresa|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (4, 'gral_info_telefono_empresa', 'Telefono de la Empresa|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (5, 'gral_info_giro_empresa', 'Giro de la Empresa|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (6, 'gral_info_tipo_contribuyente_empresa', '0|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (7, 'gral_info_nit_empresa', '000-000000-000-0|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (8, 'gral_info_nrc_empresa', '00000-0|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (9, 'gral_info_logo_empresa', 'assets/img/logo.jpg|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (10, 'realizar_respaldos_auto', 'true|b');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (11, 'realizar_respaldos_usb', 'false|b');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (12, 'realizar_respaldos_nube', 'false|b');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (13, 'ruta_respaldos_usb', '|s');
INSERT INTO `config` (`id_config`, `campo_config`, `valor_config`) VALUES (14, 'fecha_ultimo_respaldo', '2018-07-10|s');


#
# TABLE STRUCTURE FOR: cuotas
#

DROP TABLE IF EXISTS `cuotas`;

CREATE TABLE `cuotas` (
  `id_cuota` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_plan` mediumint(8) unsigned NOT NULL,
  `correlativo_cuota` tinyint(2) unsigned NOT NULL,
  `fecha_cuota` date NOT NULL,
  `monto_cuota` decimal(7,3) unsigned NOT NULL,
  `estado_cuota` tinyint(1) unsigned NOT NULL COMMENT 'Pago: 0-pendiente,1-parcial,2-pago total',
  `confirmado_cuota` tinyint(1) unsigned NOT NULL COMMENT '0-sin confirmar,1-confirmado',
  `id_transaccion` bigint(20) unsigned DEFAULT NULL,
  `pago_total` decimal(7,3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_cuota`),
  KEY `cuotas_plan` (`id_plan`),
  KEY `cuotas_transaccion` (`id_transaccion`),
  CONSTRAINT `cuotas_ingreso_fk` FOREIGN KEY (`id_transaccion`) REFERENCES `transacciones` (`id_transaccion`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `cuotas_plan_fk` FOREIGN KEY (`id_plan`) REFERENCES `planes_pago` (`id_plan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=558 DEFAULT CHARSET=latin1;

INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (1, 1, 1, '2018-07-27', '50.000', 2, 0, '1', '50.000');
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (2, 1, 2, '2018-08-27', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (3, 1, 3, '2018-09-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (4, 1, 4, '2018-10-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (5, 1, 5, '2018-11-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (6, 1, 6, '2018-12-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (7, 1, 7, '2019-01-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (8, 1, 8, '2019-02-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (9, 1, 9, '2019-03-27', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (10, 1, 10, '2019-04-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (11, 1, 11, '2019-05-27', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (12, 1, 12, '2019-06-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (13, 1, 13, '2019-07-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (14, 1, 14, '2019-08-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (15, 1, 15, '2019-09-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (16, 1, 16, '2019-10-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (17, 1, 17, '2019-11-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (18, 1, 18, '2019-12-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (19, 1, 19, '2020-01-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (20, 1, 20, '2020-02-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (21, 1, 21, '2020-03-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (22, 1, 22, '2020-04-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (23, 1, 23, '2020-05-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (24, 1, 24, '2020-06-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (25, 2, 1, '2018-07-13', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (26, 2, 2, '2018-08-14', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (27, 2, 3, '2018-09-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (28, 2, 4, '2018-10-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (29, 2, 5, '2018-11-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (30, 2, 6, '2018-12-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (31, 2, 7, '2019-01-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (32, 2, 8, '2019-02-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (33, 2, 9, '2019-03-27', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (34, 2, 10, '2019-04-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (35, 2, 11, '2019-05-27', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (36, 2, 12, '2019-06-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (37, 2, 13, '2019-07-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (38, 2, 14, '2019-08-26', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (39, 2, 15, '2019-09-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (40, 2, 16, '2019-10-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (41, 2, 17, '2019-11-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (42, 2, 18, '2019-12-25', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (43, 2, 19, '2020-01-24', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (44, 3, 1, '2018-07-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (45, 3, 2, '2018-08-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (46, 3, 3, '2018-09-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (47, 3, 4, '2018-10-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (48, 3, 5, '2018-11-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (49, 3, 6, '2018-12-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (50, 3, 7, '2019-01-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (51, 3, 8, '2019-02-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (52, 3, 9, '2019-03-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (53, 3, 10, '2019-04-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (54, 3, 11, '2019-05-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (55, 3, 12, '2019-06-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (56, 3, 13, '2019-07-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (57, 3, 14, '2019-08-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (58, 3, 15, '2019-09-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (59, 3, 16, '2019-10-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (60, 3, 17, '2019-11-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (61, 3, 18, '2019-12-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (62, 3, 19, '2020-01-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (63, 3, 20, '2020-02-21', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (64, 3, 21, '2020-03-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (158, 8, 1, '2018-07-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (159, 8, 2, '2018-08-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (160, 8, 3, '2018-09-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (161, 8, 4, '2018-10-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (162, 8, 5, '2018-11-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (163, 8, 6, '2018-12-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (164, 8, 7, '2019-01-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (165, 8, 8, '2019-02-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (166, 8, 9, '2019-03-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (167, 8, 10, '2019-04-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (168, 8, 11, '2019-05-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (169, 8, 12, '2019-06-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (170, 8, 13, '2019-07-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (171, 8, 14, '2019-08-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (172, 8, 15, '2019-09-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (173, 8, 16, '2019-10-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (174, 8, 17, '2019-11-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (175, 8, 18, '2019-12-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (176, 8, 19, '2020-01-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (177, 8, 20, '2020-02-05', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (178, 8, 21, '2020-03-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (179, 8, 22, '2020-04-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (180, 8, 23, '2020-05-06', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (181, 9, 1, '2018-07-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (182, 9, 2, '2018-08-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (183, 9, 3, '2018-09-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (184, 9, 4, '2018-10-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (185, 9, 5, '2018-11-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (186, 9, 6, '2018-12-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (187, 9, 7, '2019-01-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (188, 9, 8, '2019-02-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (189, 9, 9, '2019-03-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (190, 9, 10, '2019-04-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (191, 9, 11, '2019-05-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (192, 9, 12, '2019-06-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (193, 9, 13, '2019-07-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (194, 9, 14, '2019-08-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (195, 9, 15, '2019-09-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (196, 9, 16, '2019-10-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (197, 9, 17, '2019-11-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (198, 9, 18, '2019-12-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (199, 9, 19, '2020-01-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (200, 9, 20, '2020-02-07', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (201, 9, 21, '2020-03-09', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (202, 9, 22, '2020-04-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (203, 9, 23, '2020-05-08', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (204, 10, 1, '2018-07-26', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (205, 10, 2, '2018-08-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (206, 10, 3, '2018-09-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (207, 10, 4, '2018-10-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (208, 10, 5, '2018-11-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (209, 10, 6, '2018-12-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (210, 10, 7, '2019-01-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (211, 10, 8, '2019-02-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (212, 10, 9, '2019-03-25', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (213, 10, 10, '2019-04-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (214, 10, 11, '2019-05-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (215, 10, 12, '2019-06-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (216, 10, 13, '2019-07-24', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (217, 10, 14, '2019-08-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (218, 10, 15, '2019-09-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (219, 10, 16, '2019-10-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (220, 10, 17, '2019-11-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (221, 10, 18, '2019-12-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (222, 10, 19, '2020-01-22', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (223, 10, 20, '2020-02-21', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (224, 10, 21, '2020-03-23', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (225, 11, 1, '2018-07-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (226, 11, 2, '2018-08-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (227, 11, 3, '2018-09-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (228, 11, 4, '2018-10-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (229, 11, 5, '2018-10-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (230, 11, 6, '2018-11-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (231, 11, 7, '2018-12-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (232, 11, 8, '2019-01-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (233, 11, 9, '2019-03-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (234, 11, 10, '2019-04-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (235, 11, 11, '2019-05-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (236, 11, 12, '2019-05-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (237, 11, 13, '2019-07-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (238, 11, 14, '2019-07-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (239, 11, 15, '2019-08-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (240, 11, 16, '2019-09-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (241, 11, 17, '2019-10-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (242, 11, 18, '2019-11-29', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (243, 11, 19, '2019-12-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (244, 11, 20, '2020-01-29', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (245, 11, 21, '2020-02-28', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (246, 11, 22, '2020-03-30', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (247, 11, 23, '2020-04-29', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (272, 13, 1, '2018-07-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (273, 13, 2, '2018-08-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (274, 13, 3, '2018-09-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (275, 13, 4, '2018-10-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (276, 13, 5, '2018-11-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (277, 13, 6, '2018-12-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (278, 13, 7, '2019-01-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (279, 13, 8, '2019-02-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (280, 13, 9, '2019-03-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (281, 13, 10, '2019-04-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (282, 13, 11, '2019-05-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (283, 13, 12, '2019-06-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (284, 13, 13, '2019-07-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (285, 13, 14, '2019-08-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (286, 13, 15, '2019-09-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (287, 13, 16, '2019-10-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (288, 13, 17, '2019-11-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (289, 13, 18, '2019-12-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (290, 13, 19, '2020-01-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (291, 13, 20, '2020-02-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (292, 13, 21, '2020-03-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (293, 13, 22, '2020-04-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (294, 13, 23, '2020-05-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (295, 14, 1, '2018-07-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (296, 14, 2, '2018-08-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (297, 14, 3, '2018-09-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (298, 14, 4, '2018-10-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (299, 14, 5, '2018-11-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (300, 14, 6, '2018-12-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (301, 14, 7, '2019-01-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (302, 14, 8, '2019-02-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (303, 14, 9, '2019-03-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (304, 14, 10, '2019-04-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (305, 14, 11, '2019-05-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (306, 14, 12, '2019-06-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (307, 14, 13, '2019-07-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (308, 14, 14, '2019-08-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (309, 14, 15, '2019-09-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (310, 14, 16, '2019-10-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (311, 14, 17, '2019-11-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (312, 14, 18, '2019-12-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (313, 14, 19, '2020-01-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (314, 14, 20, '2020-02-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (315, 14, 21, '2020-03-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (316, 14, 22, '2020-04-10', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (317, 14, 23, '2020-05-11', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (318, 15, 1, '2018-07-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (319, 15, 2, '2018-08-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (320, 15, 3, '2018-09-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (321, 15, 4, '2018-10-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (322, 15, 5, '2018-11-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (323, 15, 6, '2018-12-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (324, 15, 7, '2019-01-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (325, 15, 8, '2019-02-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (326, 15, 9, '2019-03-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (327, 15, 10, '2019-04-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (328, 15, 11, '2019-05-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (329, 15, 12, '2019-06-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (330, 15, 13, '2019-07-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (331, 15, 14, '2019-08-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (332, 15, 15, '2019-09-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (333, 15, 16, '2019-10-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (334, 15, 17, '2019-11-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (335, 15, 18, '2019-12-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (336, 15, 19, '2020-01-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (337, 15, 20, '2020-01-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (338, 15, 21, '2020-03-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (339, 15, 22, '2020-04-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (340, 15, 23, '2020-05-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (341, 15, 24, '2020-06-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (342, 16, 1, '2018-07-05', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (343, 16, 2, '2018-08-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (344, 16, 3, '2018-09-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (345, 16, 4, '2018-10-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (346, 16, 5, '2018-11-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (347, 16, 6, '2018-12-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (348, 16, 7, '2019-01-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (349, 16, 8, '2019-02-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (350, 16, 9, '2019-03-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (351, 16, 10, '2019-04-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (352, 16, 11, '2019-05-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (353, 16, 12, '2019-06-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (354, 16, 13, '2019-07-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (355, 16, 14, '2019-08-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (356, 16, 15, '2019-09-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (357, 16, 16, '2019-10-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (358, 16, 17, '2019-11-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (359, 16, 18, '2019-12-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (360, 16, 19, '2020-01-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (361, 16, 20, '2020-01-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (362, 16, 21, '2020-03-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (363, 16, 22, '2020-04-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (364, 16, 23, '2020-05-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (365, 16, 24, '2020-06-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (366, 17, 1, '2018-07-07', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (367, 17, 2, '2018-08-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (368, 17, 3, '2018-09-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (369, 17, 4, '2018-10-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (370, 17, 5, '2018-11-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (371, 17, 6, '2018-12-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (372, 17, 7, '2019-01-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (373, 17, 8, '2019-02-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (374, 17, 9, '2019-03-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (375, 17, 10, '2019-04-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (376, 17, 11, '2019-05-06', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (377, 17, 12, '2019-06-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (378, 17, 13, '2019-07-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (379, 17, 14, '2019-08-05', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (380, 17, 15, '2019-09-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (381, 17, 16, '2019-10-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (382, 17, 17, '2019-11-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (383, 17, 18, '2019-12-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (384, 17, 19, '2020-01-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (385, 17, 20, '2020-02-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (386, 17, 21, '2020-03-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (387, 17, 22, '2020-04-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (388, 17, 23, '2020-05-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (389, 17, 24, '2020-06-03', '25.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (390, 18, 1, '2018-07-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (391, 18, 2, '2018-08-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (392, 18, 3, '2018-09-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (393, 18, 4, '2018-10-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (394, 18, 5, '2018-11-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (395, 18, 6, '2018-12-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (396, 18, 7, '2019-01-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (397, 18, 8, '2019-02-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (398, 18, 9, '2019-03-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (399, 18, 10, '2019-04-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (400, 18, 11, '2019-05-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (401, 18, 12, '2019-06-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (402, 18, 13, '2019-07-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (403, 18, 14, '2019-08-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (404, 18, 15, '2019-09-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (405, 18, 16, '2019-10-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (406, 18, 17, '2019-11-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (407, 18, 18, '2019-12-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (408, 18, 19, '2020-01-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (409, 18, 20, '2020-01-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (410, 18, 21, '2020-03-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (411, 18, 22, '2020-04-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (412, 18, 23, '2020-05-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (413, 18, 24, '2020-06-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (414, 19, 1, '2018-07-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (415, 19, 2, '2018-08-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (416, 19, 3, '2018-09-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (417, 19, 4, '2018-10-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (418, 19, 5, '2018-11-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (419, 19, 6, '2018-12-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (420, 19, 7, '2019-01-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (421, 19, 8, '2019-02-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (422, 19, 9, '2019-03-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (423, 19, 10, '2019-04-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (424, 19, 11, '2019-05-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (425, 19, 12, '2019-06-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (426, 19, 13, '2019-07-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (427, 19, 14, '2019-08-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (428, 19, 15, '2019-09-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (429, 19, 16, '2019-10-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (430, 19, 17, '2019-11-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (431, 19, 18, '2019-12-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (432, 19, 19, '2020-01-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (433, 19, 20, '2020-02-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (434, 19, 21, '2020-03-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (435, 19, 22, '2020-04-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (436, 19, 23, '2020-05-13', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (437, 19, 24, '2020-06-12', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (438, 20, 1, '2018-07-19', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (439, 20, 2, '2018-08-18', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (440, 20, 3, '2018-09-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (441, 20, 4, '2018-10-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (442, 20, 5, '2018-11-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (443, 20, 6, '2018-12-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (444, 20, 7, '2019-01-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (445, 20, 8, '2019-02-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (446, 20, 9, '2019-03-18', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (447, 20, 10, '2019-04-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (448, 20, 11, '2019-05-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (449, 20, 12, '2019-06-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (450, 20, 13, '2019-07-17', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (451, 20, 14, '2019-08-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (452, 20, 15, '2019-09-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (453, 20, 16, '2019-10-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (454, 20, 17, '2019-11-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (455, 20, 18, '2019-12-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (456, 20, 19, '2020-01-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (457, 20, 20, '2020-02-14', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (458, 20, 21, '2020-03-16', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (459, 20, 22, '2020-04-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (460, 20, 23, '2020-05-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (461, 20, 24, '2020-06-15', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (462, 21, 1, '2018-08-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (463, 21, 2, '2018-09-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (464, 21, 3, '2018-10-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (465, 21, 4, '2018-11-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (466, 21, 5, '2018-12-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (467, 21, 6, '2019-01-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (468, 21, 7, '2019-02-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (469, 21, 8, '2019-03-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (470, 21, 9, '2019-04-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (471, 21, 10, '2019-05-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (472, 21, 11, '2019-06-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (473, 21, 12, '2019-07-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (474, 21, 13, '2019-08-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (475, 21, 14, '2019-09-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (476, 21, 15, '2019-10-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (477, 21, 16, '2019-11-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (478, 21, 17, '2019-12-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (479, 21, 18, '2020-01-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (480, 21, 19, '2020-01-31', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (481, 21, 20, '2020-03-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (482, 21, 21, '2020-04-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (483, 21, 22, '2020-05-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (484, 21, 23, '2020-06-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (485, 21, 24, '2020-07-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (486, 22, 1, '2018-08-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (487, 22, 2, '2018-09-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (488, 22, 3, '2018-10-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (489, 22, 4, '2018-11-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (490, 22, 5, '2018-12-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (491, 22, 6, '2019-01-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (492, 22, 7, '2019-02-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (493, 22, 8, '2019-03-04', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (494, 22, 9, '2019-04-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (495, 22, 10, '2019-05-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (496, 22, 11, '2019-06-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (497, 22, 12, '2019-07-03', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (498, 22, 13, '2019-08-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (499, 22, 14, '2019-09-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (500, 22, 15, '2019-10-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (501, 22, 16, '2019-11-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (502, 22, 17, '2019-12-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (503, 22, 18, '2020-01-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (504, 22, 19, '2020-01-31', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (505, 22, 20, '2020-03-02', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (506, 22, 21, '2020-04-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (507, 22, 22, '2020-05-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (508, 22, 23, '2020-06-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (509, 22, 24, '2020-07-01', '35.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (510, 23, 1, '2018-08-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (511, 23, 2, '2018-09-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (512, 23, 3, '2018-10-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (513, 23, 4, '2018-11-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (514, 23, 5, '2018-12-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (515, 23, 6, '2019-01-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (516, 23, 7, '2019-02-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (517, 23, 8, '2019-03-04', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (518, 23, 9, '2019-04-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (519, 23, 10, '2019-05-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (520, 23, 11, '2019-06-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (521, 23, 12, '2019-07-03', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (522, 23, 13, '2019-08-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (523, 23, 14, '2019-09-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (524, 23, 15, '2019-10-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (525, 23, 16, '2019-11-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (526, 23, 17, '2019-12-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (527, 23, 18, '2020-01-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (528, 23, 19, '2020-01-31', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (529, 23, 20, '2020-03-02', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (530, 23, 21, '2020-04-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (531, 23, 22, '2020-05-01', '50.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (532, 24, 1, '2018-08-06', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (533, 24, 2, '2018-09-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (534, 24, 3, '2018-10-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (535, 24, 4, '2018-11-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (536, 24, 5, '2018-12-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (537, 24, 6, '2019-01-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (538, 24, 7, '2019-02-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (539, 24, 8, '2019-03-06', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (540, 24, 9, '2019-04-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (541, 24, 10, '2019-05-06', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (542, 24, 11, '2019-06-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (543, 24, 12, '2019-07-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (544, 24, 13, '2019-08-05', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (545, 24, 14, '2019-09-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (546, 24, 15, '2019-10-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (547, 24, 16, '2019-11-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (548, 24, 17, '2019-12-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (549, 24, 18, '2020-01-03', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (550, 24, 19, '2020-02-03', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (551, 24, 20, '2020-03-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (552, 24, 21, '2020-04-03', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (553, 24, 22, '2020-05-04', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (554, 24, 23, '2020-06-03', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (555, 24, 24, '2020-07-03', '30.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (556, 25, 1, '2018-07-09', '100.000', 0, 0, NULL, NULL);
INSERT INTO `cuotas` (`id_cuota`, `id_plan`, `correlativo_cuota`, `fecha_cuota`, `monto_cuota`, `estado_cuota`, `confirmado_cuota`, `id_transaccion`, `pago_total`) VALUES (557, 25, 2, '2018-07-10', '100.000', 0, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: departamentos
#

DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id_departamento` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_departamento` varchar(25) NOT NULL,
  PRIMARY KEY (`id_departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (1, 'AHUACHAPAN');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (2, 'SANTA ANA');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (3, 'SONSONATE');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (4, 'CHALATENANGO');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (5, 'LA LIBERTAD');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (6, 'SAN SALVADOR');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (7, 'CUSCATLAN');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (8, 'LA PAZ');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (9, 'CABANAS');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (10, 'SAN VICENTE');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (11, 'USULUTAN');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (12, 'SAN MIGUEL');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (13, 'MORAZAN');
INSERT INTO `departamentos` (`id_departamento`, `nombre_departamento`) VALUES (14, 'LA UNION');


#
# TABLE STRUCTURE FOR: grupos_servicios
#

DROP TABLE IF EXISTS `grupos_servicios`;

CREATE TABLE `grupos_servicios` (
  `id_grupo` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_grupo` varchar(128) NOT NULL,
  PRIMARY KEY (`id_grupo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (1, 'Area Ortodoncia');
INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (2, 'Area Prostodoncia');
INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (3, 'Area Cirugia');
INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (4, 'Area Operatoria');
INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (5, 'Area Implantes');
INSERT INTO `grupos_servicios` (`id_grupo`, `nombre_grupo`) VALUES (6, 'Area Endodoncia');


#
# TABLE STRUCTURE FOR: municipios
#

DROP TABLE IF EXISTS `municipios`;

CREATE TABLE `municipios` (
  `id_municipio` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `id_departamento` tinyint(2) unsigned NOT NULL,
  `nombre_municipio` varchar(60) NOT NULL,
  PRIMARY KEY (`id_municipio`),
  KEY `departamento_municipio` (`id_departamento`),
  CONSTRAINT `departamento_municipio_fk` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id_departamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=latin1;

INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (1, 1, 'AHUACHAPAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (2, 1, 'APANECA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (3, 1, 'ATIQUIZAYA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (4, 1, 'CONCEPCION DE ATACO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (5, 1, 'EL REFUGIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (6, 1, 'GUAYMANGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (7, 1, 'JUJUTLA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (8, 1, 'SAN FRANCISCO MENENDEZ');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (9, 1, 'SAN LORENZO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (10, 1, 'SAN PEDRO PUXTLA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (11, 1, 'TACUBA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (12, 1, 'TURIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (13, 2, 'SANTA ANA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (14, 2, 'CANDELARIA DE LA FRONTERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (15, 2, 'COATEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (16, 2, 'CHALCHUAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (17, 2, 'EL CONGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (18, 2, 'EL PORVENIR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (19, 2, 'MASAHUAT');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (20, 2, 'METAPAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (21, 2, 'SAN ANTONIO PAJONAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (22, 2, 'SAN SEBASTIAN SALITRILLO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (23, 2, 'SANTA ROSA GUACHIPILIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (24, 2, 'SANTIAGO DE LA FRONTERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (25, 2, 'TEXISTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (26, 3, 'SONSONATE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (27, 3, 'ACAJUTLA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (28, 3, 'ARMENIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (29, 3, 'CALUCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (30, 3, 'CUISNAHUAT');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (31, 3, 'IZALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (32, 3, 'JUAYUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (33, 3, 'NAHUIZALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (34, 3, 'NAHUILINGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (35, 3, 'SALCOATITAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (36, 3, 'SAN ANTONIO DEL MONTE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (37, 3, 'SAN JULIAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (38, 3, 'SANTA CATARINA MASAHUAT');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (39, 3, 'SANTA ISABEL ISHUATAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (40, 3, 'SANTO DOMINGO DE GUZMAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (41, 3, 'SONZACATE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (42, 4, 'CHALATENANGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (43, 4, 'AGUA CALIENTE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (44, 4, 'ARCATAO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (45, 4, 'AZACUALPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (46, 4, 'SAN JOSE CANCASQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (47, 4, 'CITALA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (48, 4, 'COMALAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (49, 4, 'CONCEPCION QUEZALTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (50, 4, 'DULCE NOMBRE DE MARIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (51, 4, 'EL CARRIZAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (52, 4, 'EL PARAISO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (53, 4, 'LA LAGUNA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (54, 4, 'LA PALMA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (55, 4, 'LA REINA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (56, 4, 'SAN JOSE LAS FLORES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (57, 4, 'LAS VUELTAS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (58, 4, 'NOMBRE DE JESUS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (59, 4, 'NUEVA CONCEPCION');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (60, 4, 'NUEVA TRINIDAD');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (61, 4, 'OJOS DE AGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (62, 4, 'POTONICO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (63, 4, 'SAN ANTONIO DE LA CRUZ');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (64, 4, 'SAN ANTONIO LOS RANCHOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (65, 4, 'SAN FERNANDO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (66, 4, 'SAN FRANCISCO LEMPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (67, 4, 'SAN FRANCISCO MORAZAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (68, 4, 'SAN IGNACIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (69, 4, 'SAN ISIDRO LABRADOR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (70, 4, 'SAN LUIS DEL CARMEN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (71, 4, 'SAN MIGUEL DE MERCEDES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (72, 4, 'SAN RAFAEL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (73, 4, 'SANTA RITA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (74, 4, 'TEJUTLA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (75, 5, 'NUEVA SAN SALVADOR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (76, 5, 'ANTIGUO CUSCATLAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (77, 5, 'CIUDAD ARCE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (78, 5, 'COLON');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (79, 5, 'COMASAGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (80, 5, 'CHILTIUPAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (81, 5, 'HUIZUCAR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (82, 5, 'JAYAQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (83, 5, 'JICALAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (84, 5, 'LA LIBERTAD');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (85, 5, 'NUEVO CUSCATLAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (86, 5, 'SAN JUAN OPICO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (87, 5, 'QUEZALTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (88, 5, 'SACACOYO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (89, 5, 'SAN JOSE VILLANUEVA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (90, 5, 'SAN MATIAS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (91, 5, 'SAN PABLO TACACHICO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (92, 5, 'TALNIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (93, 5, 'TAMANIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (94, 5, 'TEOTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (95, 5, 'TEPECOYO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (96, 5, 'ZARAGOZA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (97, 6, 'SAN SALVADOR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (98, 6, 'AGUILARES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (99, 6, 'APOPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (100, 6, 'AYUTUXTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (101, 6, 'CUSCATANCINGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (102, 6, 'CIUDAD DELGADO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (103, 6, 'EL PAISNAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (104, 6, 'GUAZAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (105, 6, 'ILOPANGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (106, 6, 'MEJICANOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (107, 6, 'NEJAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (108, 6, 'PANCHIMALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (109, 6, 'ROSARIO DE MORA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (110, 6, 'SAN MARCOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (111, 6, 'SAN MARTIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (112, 6, 'SANTIAGO TEXACUANGOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (113, 6, 'SANTO TOMAS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (114, 6, 'SOYAPANGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (115, 6, 'TONACATEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (116, 7, 'COJUTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (117, 7, 'CANDELARIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (118, 7, 'EL CARMEN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (119, 7, 'EL ROSARIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (120, 7, 'MONTE DE SAN JUAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (121, 7, 'ORATORIO DE CONCEPCION');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (122, 7, 'SAN BARTOLOME PERULAPIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (123, 7, 'SAN CRISTOBAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (124, 7, 'SAN JOSE GUAYABAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (125, 7, 'SAN PEDRO PERULAPAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (126, 7, 'SAN RAFAEL CEDROS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (127, 7, 'SAN RAMON');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (128, 7, 'SANTA CRUZ ANALQUITO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (129, 7, 'SANTA CRUZ MICHAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (130, 7, 'SUCHITOTO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (131, 7, 'TENANCINGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (132, 8, 'ZACATECOLUCA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (133, 8, 'CUYULTITAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (134, 8, 'EL ROSARIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (135, 8, 'JERUSALEN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (136, 8, 'MERCEDES LA CEIBA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (137, 8, 'OLOCUILTA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (138, 8, 'PARAISO DE OSORIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (139, 8, 'SAN ANTONIO MASAHUAT');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (140, 8, 'SAN EMIGDIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (141, 8, 'SAN FRANCISCO CHINAMECA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (142, 8, 'SAN JUAN NONUALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (143, 8, 'SAN JUAN TALPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (144, 8, 'SAN JUAN TEPEZONTES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (145, 8, 'SAN LUIS TALPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (146, 8, 'SAN LUIS LA HERRADURA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (147, 8, 'SAN MIGUEL TEPEZONTES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (148, 8, 'SAN PEDRO MASAHUAT');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (149, 8, 'SAN PEDRO NONUALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (150, 8, 'SAN RAFAEL OBRAJUELO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (151, 8, 'SANTA MARIA OSTUMA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (152, 8, 'SANTIAGO NONUALCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (153, 8, 'TAPALHUACA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (154, 9, 'SENSUNTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (155, 9, 'CINQUERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (156, 9, 'VILLA DOLORES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (157, 9, 'GUACOTECTI');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (158, 9, 'ILOBASCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (159, 9, 'JUTIAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (160, 9, 'SAN ISIDRO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (161, 9, 'TEJUTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (162, 9, 'VILLA VICTORIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (163, 10, 'SAN VICENTE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (164, 10, 'APASTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (165, 10, 'GUADALUPE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (166, 10, 'SAN CAYETANO ISTEPEQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (167, 10, 'SAN ESTEBAN CATARINA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (168, 10, 'SAN ILDEFONSO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (169, 10, 'SAN LORENZO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (170, 10, 'SAN SEBASTIAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (171, 10, 'SANTA CLARA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (172, 10, 'SANTO DOMINGO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (173, 10, 'TECOLUCA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (174, 10, 'TEPETITAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (175, 10, 'VERAPAZ');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (176, 11, 'USULUTAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (177, 11, 'ALEGRIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (178, 11, 'BERLIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (179, 11, 'CALIFORNIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (180, 11, 'CONCEPCION BATRES');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (181, 11, 'EL TRIUNFO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (182, 11, 'EREGUAYQUIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (183, 11, 'ESTANZUELAS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (184, 11, 'JIQUILISCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (185, 11, 'JUCUAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (186, 11, 'JUCUARAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (187, 11, 'MERCEDES UMAÑA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (188, 11, 'NUEVA GRANADA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (189, 11, 'OZATLAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (190, 11, 'PUERTO EL TRIUNFO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (191, 11, 'SAN AGUSTIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (192, 11, 'SAN BUENA VENTURA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (193, 11, 'SAN DIONISIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (194, 11, 'SAN FRANCISCO JAVIER');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (195, 11, 'SANTA ELENA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (196, 11, 'SANTA MARIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (197, 11, 'SANTIAGO DE MARIA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (198, 11, 'TECAPAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (199, 12, 'SAN MIGUEL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (200, 12, 'CAROLINA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (201, 12, 'CIUDAD BARRIOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (202, 12, 'COMACARAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (203, 12, 'CHAPELTIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (204, 12, 'CHINAMECA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (205, 12, 'CHIRILAGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (206, 12, 'EL TRANSITO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (207, 12, 'LOLOTIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (208, 12, 'MONCAGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (209, 12, 'NUEVA GUADALUPE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (210, 12, 'NUEVO EDEN DE SAN JUAN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (211, 12, 'QUELEPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (212, 12, 'SAN ANTONIO DEL MOSCO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (213, 12, 'SAN GERARDO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (214, 12, 'SAN JORGE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (215, 12, 'SAN LUIS DE LA REINA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (216, 12, 'SAN RAFAEL ORIENTE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (217, 12, 'SESORI');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (218, 12, 'ULUAZAPA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (219, 13, 'SAN FRANCISCO GOTERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (220, 13, 'ARAMBALA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (221, 13, 'CACAOPERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (222, 13, 'CORINTO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (223, 13, 'CHILANGA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (224, 13, 'DELICIAS DE CONCEPCION');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (225, 13, 'EL DIVISADERO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (226, 13, 'EL ROSARIO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (227, 13, 'GUALOCOCTI');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (228, 13, 'GUATAJIAGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (229, 13, 'JOATECA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (230, 13, 'JOCOAITIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (231, 13, 'JOCORO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (232, 13, 'LOLOTIQUILLO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (233, 13, 'MEANGUERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (234, 13, 'OSICALA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (235, 13, 'PERQUIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (236, 13, 'SAN CARLOS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (237, 13, 'SAN FERNANDO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (238, 13, 'SAN ISIDRO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (239, 13, 'SAN SIMON');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (240, 13, 'SENSEMBRA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (241, 13, 'SOCIEDAD');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (242, 13, 'TOROLA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (243, 13, 'YAMABAL');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (244, 13, 'YOLOAIQUIN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (245, 14, 'LA UNION');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (246, 14, 'ANAMOROS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (247, 14, 'BOLIVAR');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (248, 14, 'CONCEPCION DE ORIENTE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (249, 14, 'CONCHAGUA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (250, 14, 'EL CARMEN');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (251, 14, 'EL SAUCE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (252, 14, 'INTIPUCA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (253, 14, 'LISLIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (254, 14, 'MEANGUERA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (255, 14, 'NUEVA ESPARTA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (256, 14, 'PASAQUINA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (257, 14, 'POLOROS');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (258, 14, 'SAN ALEJO');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (259, 14, 'SAN JOSE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (260, 14, 'SANTA ROSA DE LIMA');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (261, 14, 'YAYANTIQUE');
INSERT INTO `municipios` (`id_municipio`, `id_departamento`, `nombre_municipio`) VALUES (262, 14, 'YUCUAIQUIN');


#
# TABLE STRUCTURE FOR: planes_pago
#

DROP TABLE IF EXISTS `planes_pago`;

CREATE TABLE `planes_pago` (
  `id_plan` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` smallint(4) unsigned DEFAULT NULL,
  `id_cliente` mediumint(8) unsigned NOT NULL,
  `id_servicio` smallint(5) unsigned DEFAULT NULL,
  `num_tarjeta_plan` varchar(64) DEFAULT NULL,
  `total_plan` decimal(7,2) unsigned NOT NULL,
  `prima_plan` decimal(7,2) unsigned NOT NULL,
  `financiamiento_plan` decimal(7,2) unsigned NOT NULL,
  `plazo_plan` decimal(4,2) unsigned NOT NULL,
  `tipo_plazo_plan` tinyint(1) NOT NULL,
  `cuota_plan` decimal(7,2) unsigned NOT NULL,
  `pagado_plan` decimal(7,2) unsigned NOT NULL DEFAULT '0.00',
  `creado_plan` datetime NOT NULL,
  `estado_plan` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0-activo,1-inactivo',
  PRIMARY KEY (`id_plan`),
  KEY `plan_cliente` (`id_cliente`),
  KEY `plan_usuario` (`id_usuario`),
  KEY `plan_servicio` (`id_servicio`),
  CONSTRAINT `plan_cliente_fk` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `plan_servicio_fk` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `plan_usuario_fk` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (1, 3, 1, 21, '001-0001', '1550.00', '350.00', '1200.00', '24.00', 0, '50.00', '50.00', '2018-06-27 12:27:21', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (2, 3, 2, 22, '001-0002', '865.00', '200.00', '665.00', '19.00', 0, '35.00', '0.00', '2018-06-27 14:31:13', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (3, 3, 3, 21, '001-0003', '1400.00', '350.00', '1050.00', '21.00', 0, '50.00', '0.00', '2018-06-28 07:25:19', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (8, 3, 9, 23, '001-0007', '1500.00', '350.00', '1150.00', '23.00', 0, '50.00', '0.00', '2018-06-28 09:02:18', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (9, 3, 10, 23, '001-0005', '1450.00', '300.00', '1150.00', '23.00', 0, '50.00', '0.00', '2018-06-28 09:06:19', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (10, 3, 11, 21, '001-0004', '1400.00', '350.00', '1050.00', '21.00', 0, '50.00', '0.00', '2018-06-28 09:09:23', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (11, 3, 12, 21, '001-0006', '1500.00', '350.00', '1150.00', '23.00', 0, '50.00', '0.00', '2018-06-28 09:12:26', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (13, 3, 14, 22, '001-0009', '1000.00', '200.00', '800.00', '23.00', 0, '35.00', '0.00', '2018-06-28 09:40:28', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (14, 3, 15, 21, '001-0008', '1500.00', '350.00', '1150.00', '23.00', 0, '50.00', '0.00', '2018-06-28 09:42:48', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (15, 3, 16, 21, '001-0010', '1550.00', '350.00', '1200.00', '24.00', 0, '50.00', '0.00', '2018-06-28 09:44:43', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (16, 3, 17, 21, '001-0011', '1550.00', '350.00', '1200.00', '24.00', 0, '50.00', '0.00', '2018-06-28 09:54:59', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (17, 3, 18, 22, '001-0012', '1000.00', '170.00', '830.00', '24.00', 0, '35.00', '0.00', '2018-06-28 09:58:17', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (18, 3, 19, 21, '001-0013', '1550.00', '350.00', '1200.00', '24.00', 0, '50.00', '0.00', '2018-06-28 11:51:04', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (19, 3, 20, 23, '001-0014', '1500.00', '300.00', '1200.00', '24.00', 0, '50.00', '0.00', '2018-06-28 11:55:25', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (20, 3, 21, 21, '001-0015', '1550.00', '350.00', '1200.00', '24.00', 0, '50.00', '0.00', '2018-06-28 11:57:32', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (21, 3, 22, 22, '001-0016', '1040.00', '200.00', '840.00', '24.00', 0, '35.00', '0.00', '2018-06-28 12:01:45', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (22, 3, 23, 22, '001-0017', '1040.00', '200.00', '840.00', '24.00', 0, '35.00', '0.00', '2018-06-28 12:05:45', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (23, 3, 24, 21, '001-0018', '1450.00', '350.00', '1100.00', '22.00', 0, '50.00', '0.00', '2018-06-28 12:08:26', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (24, 3, 25, 22, '001-0019', '920.00', '200.00', '720.00', '24.00', 0, '30.00', '0.00', '2018-06-28 12:10:45', 0);
INSERT INTO `planes_pago` (`id_plan`, `id_usuario`, `id_cliente`, `id_servicio`, `num_tarjeta_plan`, `total_plan`, `prima_plan`, `financiamiento_plan`, `plazo_plan`, `tipo_plazo_plan`, `cuota_plan`, `pagado_plan`, `creado_plan`, `estado_plan`) VALUES (25, 1, 1, 1, '', '300.00', '100.00', '200.00', '2.00', 2, '100.00', '0.00', '2018-07-08 19:22:42', 1);


#
# TABLE STRUCTURE FOR: servicios
#

DROP TABLE IF EXISTS `servicios`;

CREATE TABLE `servicios` (
  `id_servicio` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_grupo` smallint(4) unsigned DEFAULT NULL,
  `nombre_servicio` varchar(128) NOT NULL,
  `costo_servicio` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`id_servicio`),
  KEY `gruposerv_servicios` (`id_grupo`),
  CONSTRAINT `gruposerv_servicios_fk` FOREIGN KEY (`id_grupo`) REFERENCES `grupos_servicios` (`id_grupo`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (1, 6, 'Endodoncia con Zirconio', '300.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (2, 6, 'Endodoncia con Metal Porcelana', '350.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (3, 6, 'Reconstruccion poste de fibra', '50.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (4, 2, 'Corona Metal Porcelana', '100.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (5, 2, 'Corona Zirconio', '150.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (6, 2, 'Protesis Removible Cromo', '400.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (7, 2, 'Protesis Removible Flexible', '350.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (8, 2, 'Protesis Removible Whipla de 2 piezas', '40.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (9, 2, 'Corona de Oro en pieza natural', '100.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (10, 2, 'Corona Liga Dorada', '40.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (11, 2, 'Protesis Completa Acrilico', '150.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (12, 2, 'Protesis Completa Porcelana', '300.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (13, 2, 'Protesis Completa Caracterizada', '400.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (14, 3, 'Exodoncia Simple', '25.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (15, 3, 'Cirugia de Cordal', '70.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (16, 4, 'Obturacion de Resina', '25.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (17, 4, 'Incrustacion', '100.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (18, 4, 'Carilla', '100.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (19, 5, 'Implante GMI', '700.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (20, 5, 'Implante Nobel', '900.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (21, 1, 'Sistema Damon ', '1550.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (22, 1, 'Sistema MBT', '1040.00');
INSERT INTO `servicios` (`id_servicio`, `id_grupo`, `nombre_servicio`, `costo_servicio`) VALUES (23, 1, 'Sistema MEAW', '1500.00');


#
# TABLE STRUCTURE FOR: serviciosxtransaccion
#

DROP TABLE IF EXISTS `serviciosxtransaccion`;

CREATE TABLE `serviciosxtransaccion` (
  `id_transaccion` bigint(20) unsigned NOT NULL,
  `id_servicio` smallint(5) unsigned DEFAULT NULL,
  `cantidad_servicio` decimal(7,2) unsigned DEFAULT NULL,
  `precio_servicio` decimal(7,2) DEFAULT NULL,
  KEY `servxtrans_transaccion` (`id_transaccion`),
  KEY `servxtrans_servicio` (`id_servicio`),
  CONSTRAINT `servxtrans_servicio_fk` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `servxtrans_transaccion_fk` FOREIGN KEY (`id_transaccion`) REFERENCES `transacciones` (`id_transaccion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `serviciosxtransaccion` (`id_transaccion`, `id_servicio`, `cantidad_servicio`, `precio_servicio`) VALUES ('1', 21, '1.00', '50.00');
INSERT INTO `serviciosxtransaccion` (`id_transaccion`, `id_servicio`, `cantidad_servicio`, `precio_servicio`) VALUES ('2', 1, '1.00', '100.00');
INSERT INTO `serviciosxtransaccion` (`id_transaccion`, `id_servicio`, `cantidad_servicio`, `precio_servicio`) VALUES ('3', 5, '1.00', '150.00');
INSERT INTO `serviciosxtransaccion` (`id_transaccion`, `id_servicio`, `cantidad_servicio`, `precio_servicio`) VALUES ('3', 4, '2.00', '100.00');
INSERT INTO `serviciosxtransaccion` (`id_transaccion`, `id_servicio`, `cantidad_servicio`, `precio_servicio`) VALUES ('4', 16, '1.00', '25.00');


#
# TABLE STRUCTURE FOR: transacciones
#

DROP TABLE IF EXISTS `transacciones`;

CREATE TABLE `transacciones` (
  `id_transaccion` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` smallint(4) unsigned DEFAULT NULL,
  `id_cliente` mediumint(8) unsigned DEFAULT NULL,
  `id_cuota` int(10) unsigned DEFAULT NULL,
  `id_revertido_transaccion` bigint(20) unsigned DEFAULT NULL,
  `fecha_transaccion` datetime NOT NULL,
  `tipo_transaccion` tinyint(1) unsigned NOT NULL COMMENT '0-ingreso,1-egreso',
  `concepto_transaccion` tinyint(1) unsigned NOT NULL COMMENT '0-Prima,1-Cuota,2-Contado',
  `detalles_transaccion` varchar(255) DEFAULT NULL,
  `monto_transaccion` decimal(7,2) unsigned NOT NULL,
  `medio_transaccion` tinyint(1) unsigned DEFAULT NULL,
  `estado_transaccion` tinyint(1) unsigned NOT NULL COMMENT '0-activo,1-revertido',
  `responsable_transaccion` varchar(128) DEFAULT NULL,
  `firma_resp_transaccion` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id_transaccion`),
  KEY `trans_usuario` (`id_usuario`),
  KEY `trans_cliente` (`id_cliente`),
  KEY `trans_cuota` (`id_cuota`),
  KEY `trans_revtrans` (`id_revertido_transaccion`),
  CONSTRAINT `trans_cliente_fk` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `trans_cuota_fk` FOREIGN KEY (`id_cuota`) REFERENCES `cuotas` (`id_cuota`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `trans_revtrans_fk` FOREIGN KEY (`id_revertido_transaccion`) REFERENCES `transacciones` (`id_transaccion`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `trans_usuario_fk` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `transacciones` (`id_transaccion`, `id_usuario`, `id_cliente`, `id_cuota`, `id_revertido_transaccion`, `fecha_transaccion`, `tipo_transaccion`, `concepto_transaccion`, `detalles_transaccion`, `monto_transaccion`, `medio_transaccion`, `estado_transaccion`, `responsable_transaccion`, `firma_resp_transaccion`) VALUES ('1', 3, 1, 1, NULL, '2018-07-08 06:27:26', 0, 1, 'Pago de Cuota', '50.00', NULL, 0, 'Donatila Argueta', 'assets/img/firma.png');
INSERT INTO `transacciones` (`id_transaccion`, `id_usuario`, `id_cliente`, `id_cuota`, `id_revertido_transaccion`, `fecha_transaccion`, `tipo_transaccion`, `concepto_transaccion`, `detalles_transaccion`, `monto_transaccion`, `medio_transaccion`, `estado_transaccion`, `responsable_transaccion`, `firma_resp_transaccion`) VALUES ('2', 1, 1, NULL, NULL, '2018-07-08 06:27:26', 0, 0, NULL, '100.00', NULL, 0, 'Donatila Argueta', 'assets/img/firma.png');
INSERT INTO `transacciones` (`id_transaccion`, `id_usuario`, `id_cliente`, `id_cuota`, `id_revertido_transaccion`, `fecha_transaccion`, `tipo_transaccion`, `concepto_transaccion`, `detalles_transaccion`, `monto_transaccion`, `medio_transaccion`, `estado_transaccion`, `responsable_transaccion`, `firma_resp_transaccion`) VALUES ('3', 1, 1, NULL, NULL, '2018-07-08 06:27:26', 0, 2, NULL, '350.00', NULL, 0, 'Donatila Argueta', 'assets/img/firma.png');
INSERT INTO `transacciones` (`id_transaccion`, `id_usuario`, `id_cliente`, `id_cuota`, `id_revertido_transaccion`, `fecha_transaccion`, `tipo_transaccion`, `concepto_transaccion`, `detalles_transaccion`, `monto_transaccion`, `medio_transaccion`, `estado_transaccion`, `responsable_transaccion`, `firma_resp_transaccion`) VALUES ('4', 1, NULL, NULL, NULL, '2018-07-09 16:39:25', 0, 2, 'Pago de servicio al contado', '25.00', 0, 0, 'Omarcito', 'assets/img/sig-default.jpg');


#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id_usuario` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(128) NOT NULL,
  `username_usuario` varchar(64) NOT NULL,
  `password_usuario` varchar(64) NOT NULL,
  `permisos_usuario` mediumtext,
  `img_perfil_usuario` varchar(128) DEFAULT NULL,
  `thumb_perfil_usuario` varchar(128) DEFAULT NULL,
  `conectado_usuario` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-desconectado,1-conectado',
  `activo_usuario` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0-inactivo,1-activo',
  `activo_desde_usuario` datetime DEFAULT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (1, 'Xypnos', 'root', '74de32e66588de47b89f31e7c4a37301c48dd8e4', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/5.png', 'assets/img/profile-photos/5.png', 1, 1, '2018-06-10 03:15:24');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (3, 'Ana Hernandez', 'ana', '72019bbac0b3dac88beac9ddfef0ca808919104f', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:0;s:17:\"eliminar_clientes\";b:0;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:0;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:0;s:18:\"ver_reportes_texto\";b:0;s:20:\"ver_reportes_grafico\";b:0;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:0;s:29:\"editar_administracion_general\";b:0;s:28:\"ver_administracion_servicios\";b:0;s:37:\"crear_editar_administracion_servicios\";b:0;s:33:\"eliminar_administracion_servicios\";b:0;s:27:\"ver_administracion_usuarios\";b:0;s:36:\"crear_editar_administracion_usuarios\";b:0;s:32:\"eliminar_administracion_usuarios\";b:0;s:32:\"bloquear_administracion_usuarios\";b:0;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:0;s:34:\"modificar_administracion_respaldos\";b:0;}}', 'assets/img/profile-photos/10.png', 'assets/img/profile-photos/10.png', 0, 1, '2018-06-26 13:33:05');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (6, 'Albin Padilla', 'albin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/1.png', 'assets/img/profile-photos/1.png', 1, 1, '2018-07-06 09:39:03');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (7, 'Paola Padilla', 'paola', '825e064b2c85b54b1e40c143e31f24c19bbac07b', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/10.png', 'assets/img/profile-photos/10.png', 0, 1, '2018-07-06 09:40:09');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (8, 'Veronica Padilla', 'veronica', 'aa2b7cf7f51e8e6fe7d016f4e3e9645e29ae7f90', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/9.png', 'assets/img/profile-photos/9.png', 0, 1, '2018-07-06 09:40:29');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (9, 'Alvin Padilla', 'alvin', '59d97cb9530a12325b70e648432cc8de75741c2c', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/4.png', 'assets/img/profile-photos/4.png', 0, 1, '2018-07-06 09:40:47');
INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `username_usuario`, `password_usuario`, `permisos_usuario`, `img_perfil_usuario`, `thumb_perfil_usuario`, `conectado_usuario`, `activo_usuario`, `activo_desde_usuario`) VALUES (10, 'Ninfa de Padilla', 'ninfa', 'a84b91d87796e7278c6bff5a821124be7fd20851', 'a:3:{s:8:\"clientes\";a:14:{s:12:\"ver_clientes\";b:1;s:14:\"crear_clientes\";b:1;s:15:\"editar_clientes\";b:1;s:17:\"eliminar_clientes\";b:1;s:21:\"ver_historial_cliente\";b:1;s:27:\"registrar_historial_cliente\";b:1;s:26:\"ver_estado_cuentas_cliente\";b:1;s:21:\"ver_plan_pago_cliente\";b:1;s:23:\"crear_plan_pago_cliente\";b:1;s:26:\"exportar_plan_pago_cliente\";b:1;s:17:\"ver_pagos_cliente\";b:1;s:19:\"crear_pagos_cliente\";b:1;s:22:\"revertir_pagos_cliente\";b:1;s:25:\"ver_resumen_transacciones\";b:1;}s:8:\"reportes\";a:3:{s:12:\"ver_reportes\";b:1;s:18:\"ver_reportes_texto\";b:1;s:20:\"ver_reportes_grafico\";b:1;}s:14:\"administracion\";a:13:{s:18:\"ver_administracion\";b:1;s:26:\"ver_administracion_general\";b:1;s:29:\"editar_administracion_general\";b:1;s:28:\"ver_administracion_servicios\";b:1;s:37:\"crear_editar_administracion_servicios\";b:1;s:33:\"eliminar_administracion_servicios\";b:1;s:27:\"ver_administracion_usuarios\";b:1;s:36:\"crear_editar_administracion_usuarios\";b:1;s:32:\"eliminar_administracion_usuarios\";b:1;s:32:\"bloquear_administracion_usuarios\";b:1;s:30:\"hacer_administracion_respaldos\";b:1;s:34:\"restaurar_administracion_respaldos\";b:1;s:34:\"modificar_administracion_respaldos\";b:1;}}', 'assets/img/profile-photos/7.png', 'assets/img/profile-photos/7.png', 0, 1, '2018-07-06 09:41:10');


#
# TABLE STRUCTURE FOR: visitas
#

DROP TABLE IF EXISTS `visitas`;

CREATE TABLE `visitas` (
  `id_visita` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` mediumint(8) unsigned NOT NULL,
  `id_usuario` smallint(4) unsigned DEFAULT NULL,
  `fecha_visita` date NOT NULL,
  `texto_visita` text,
  `img_visita` text,
  PRIMARY KEY (`id_visita`),
  KEY `cliente_visita` (`id_cliente`),
  KEY `usuario_visita` (`id_usuario`),
  CONSTRAINT `cliente_visita_fk` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `usuario_visita_fk` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

